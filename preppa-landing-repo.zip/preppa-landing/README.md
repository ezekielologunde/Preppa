# Preppa Landing & Learning Hub

Production-ready Next.js landing site for `preppa.live`, combining:

- the strongest messaging from the existing landing page
- customer and Prepper marketing
- meal plans, subscriptions, services, experiences, quotes, creator feed, and payout positioning
- a public training center
- legal and safety framework pages
- Vercel Analytics and Speed Insights
- accessible, reduced-motion-aware animation

## Local setup

```bash
npm install
cp .env.example .env.local
npm run dev
```

## Quality gate

```bash
npm run check
```

## Waitlist

Set `WAITLIST_WEBHOOK_URL` to a secure server-side endpoint that accepts:

```json
{ "email": "...", "zip": "...", "role": "customer|prepper|both", "source": "preppa.live", "submittedAt": "ISO date" }
```

No production database or provider secret is exposed to the browser.

## GitHub repository

This package is Git-ready, but repository creation requires an authenticated GitHub session:

```bash
git init
git add .
git commit -m "feat: launch Preppa marketing and learning hub"
gh repo create preppa-landing --private --source=. --remote=origin --push
```

## Connect the existing Vercel project

The supplied Vercel project ID is documented in `docs/DEPLOYMENT.md`. Do not commit `.vercel/`.

```bash
npm i -g vercel
vercel login
vercel link
vercel env pull .env.local
vercel --prod
```

After the repository exists, connect or replace the Git repository in Vercel Project Settings → Git. Confirm `preppa.live` remains assigned to the intended Production project before disconnecting the current repository.

## Design process

Impeccable, UI/UX Pro Max, and similar agent design skills should be used for critique and refinement, not as runtime dependencies. The source of truth is the repository design tokens, accessibility rules, user journeys, and visual regression review.
