export type LegalPage = {
  slug: string;
  title: string;
  summary: string;
  sections: { heading: string; paragraphs: string[]; bullets?: string[] }[];
};

export const legalPages: LegalPage[] = [
  {
    slug: "privacy",
    title: "Privacy overview",
    summary: "A plain-language map of the information Preppa may need and why.",
    sections: [
      { heading: "Status of this page", paragraphs: ["This is a product-content framework, not the final legal privacy notice. Final language must be reviewed by qualified privacy counsel before launch."] },
      { heading: "Information categories", paragraphs: ["Preppa may process account, profile, preference, transaction, communication, device, location-area, and marketplace safety information."], bullets: ["Sensitive payment and identity verification information should be collected directly by approved payment providers.", "Precise residential kitchen addresses should not be displayed publicly without a valid fulfillment need."] },
      { heading: "User controls", paragraphs: ["The final notice should explain access, correction, deletion, marketing preferences, location controls, retention, and jurisdiction-specific rights."] },
    ],
  },
  {
    slug: "terms",
    title: "Terms framework",
    summary: "The commercial and community rules that must be finalized before launch.",
    sections: [
      { heading: "Status of this page", paragraphs: ["This page is an implementation framework only. It is not a substitute for attorney-drafted Terms of Service."] },
      { heading: "Topics requiring final terms", paragraphs: ["Final terms should cover eligibility, account duties, marketplace role, payment processing, fees, cancellations, disputes, user content, prohibited conduct, suspension, liability, and governing law."] },
      { heading: "Marketplace clarity", paragraphs: ["The final document must accurately state whether Preppa acts as a marketplace, payment facilitator, booking intermediary, delivery coordinator, or another legally defined role in each supported jurisdiction."] },
    ],
  },
  {
    slug: "community-guidelines",
    title: "Community guidelines",
    summary: "Expected conduct for customers, Preppas, creators, and live participants.",
    sections: [
      { heading: "Be truthful", paragraphs: ["Do not misrepresent food, credentials, kitchen status, availability, reviews, pricing, identity, or service outcomes."] },
      { heading: "Keep people safe", paragraphs: ["No harassment, threats, discriminatory conduct, sexual exploitation, dangerous challenges, or instructions designed to evade food-safety requirements."] },
      { heading: "Keep commerce on-platform", paragraphs: ["Do not solicit off-platform payments, request authentication codes, or send financial credentials in chat."] },
      { heading: "Creator content", paragraphs: ["Videos and livestreams must accurately represent the Prepper and offerings. Moderators may restrict content, chat, commerce, or accounts when safety or integrity is at risk."] },
    ],
  },
  {
    slug: "preppa-standards",
    title: "Prepper standards",
    summary: "Minimum expectations for listings, fulfillment, communication, and customer trust.",
    sections: [
      { heading: "Approval and status", paragraphs: ["Application submission does not grant Prepper access. Only approved and non-suspended Preppas may operate My Hub, and paid commerce requires enabled payouts."] },
      { heading: "Offering quality", paragraphs: ["Provide accurate ingredients, allergens, portions, photos, lead times, capacity, pickup or delivery terms, and cancellation policies."] },
      { heading: "Reliable fulfillment", paragraphs: ["Confirm orders promptly, maintain availability, protect customer information, communicate delays, and complete platform status updates honestly."] },
    ],
  },
  {
    slug: "refunds-and-cancellations",
    title: "Refund and cancellation framework",
    summary: "A clear structure for meals, subscriptions, bookings, deposits, and custom quotes.",
    sections: [
      { heading: "Different products need different rules", paragraphs: ["Single meals, recurring cycles, instant-booked experiences, and custom service quotes should not share one vague cancellation policy."] },
      { heading: "Policy principles", paragraphs: ["Terms should disclose deadlines, non-refundable work, deposit treatment, payment failures, Prepper cancellation, customer cancellation, rescheduling, and platform intervention."] },
      { heading: "Final review", paragraphs: ["Finance, operations, payment-provider, insurance, and legal stakeholders must approve the final matrix before launch."] },
    ],
  },
];

export const legalBySlug = Object.fromEntries(legalPages.map((page) => [page.slug, page]));
