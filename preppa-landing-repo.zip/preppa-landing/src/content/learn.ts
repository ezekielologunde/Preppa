export type Guide = {
  slug: string;
  title: string;
  summary: string;
  audience: "Customers" | "Preppas" | "Everyone";
  minutes: number;
  steps: { title: string; body: string }[];
  note?: string;
};

export const guides: Guide[] = [
  {
    slug: "become-a-preppa",
    title: "Apply to become a Preppa",
    summary: "How approval works, what the platform checks, and what you can prepare while your application is reviewed.",
    audience: "Preppas",
    minutes: 4,
    steps: [
      { title: "Start as a customer", body: "Every account begins with customer access. Applying does not automatically unlock My Hub." },
      { title: "Submit your application", body: "Complete your identity, kitchen, service-area, food-safety, and experience details accurately." },
      { title: "Wait for admin review", body: "Your status may be under review, changes requested, approved, or rejected. Preppa access is granted only after approval." },
      { title: "Open My Hub", body: "After approval, a welcome notice appears and My Hub becomes available for setup." },
    ],
  },
  {
    slug: "post-your-first-meal",
    title: "Post your first meal",
    summary: "Turn a dish into a clear, trustworthy offering customers can actually understand and order.",
    audience: "Preppas",
    minutes: 6,
    steps: [
      { title: "Create a draft", body: "Add a specific name, useful description, cuisine, category, and portion details." },
      { title: "Add honest food details", body: "List ingredients, allergens, dietary tags, preparation time, storage guidance, and reheating instructions." },
      { title: "Add media", body: "Upload clear photos or a short video that accurately represents the meal. Avoid misleading edits or unrelated imagery." },
      { title: "Set fulfillment", body: "Choose pickup, scheduled delivery, lead time, available dates, capacity, and pricing." },
      { title: "Preview and publish", body: "Review the customer-facing page. Paid listings require approved Prepper status and enabled payouts." },
    ],
  },
  {
    slug: "create-a-meal-plan",
    title: "Create a meal plan",
    summary: "Build a weekly or biweekly package with a clear cadence, menu, capacity, pricing, and customer controls.",
    audience: "Preppas",
    minutes: 8,
    steps: [
      { title: "Define the promise", body: "Choose who the plan is for, how many meals it includes, serving sizes, cuisine, and dietary options." },
      { title: "Choose the menu model", body: "Use a fixed menu or let customers choose from eligible meals. Set substitution and add-on rules." },
      { title: "Set the cycle", body: "Configure weekly or biweekly billing, selection deadlines, prep days, and pickup or delivery windows." },
      { title: "Protect your capacity", body: "Set a subscriber limit and account for one-time meals, Drops, and service bookings." },
      { title: "Publish enrollment terms", body: "Explain trial, skip, pause, cancellation, and refund policies before activation." },
    ],
  },
  {
    slug: "set-up-payouts",
    title: "Set up secure payouts",
    summary: "Connect your payout destination without giving Preppa your raw banking credentials.",
    audience: "Preppas",
    minutes: 4,
    steps: [
      { title: "Wait for approval", body: "Only approved Preppas can begin payout onboarding." },
      { title: "Open Payouts in My Hub", body: "Choose Set up payouts. Preppa opens the secure payment provider onboarding flow." },
      { title: "Provide details securely", body: "Enter eligible bank or debit-card details directly with the payment provider, not inside Preppa." },
      { title: "Complete verification", body: "Some accounts may need identity or business verification. Your status updates after provider confirmation." },
      { title: "Start earning", body: "Once payouts are enabled, you may publish paid offerings and receive released earnings." },
    ],
    note: "Preppa should never request routing numbers, full account numbers, identity documents, or tax IDs through chat, email, or social media.",
  },
  {
    slug: "offer-an-experience",
    title: "Offer a food experience",
    summary: "Create a cooking class, private dinner, catering service, or cook-at-home offering with the right booking model.",
    audience: "Preppas",
    minutes: 7,
    steps: [
      { title: "Choose the service type", body: "Decide whether the experience is instant-bookable or requires a request and quote." },
      { title: "Describe what is included", body: "List duration, guest limits, ingredients, travel, equipment, setup, cleanup, and accessibility details." },
      { title: "Set availability and pricing", body: "Use flat, per-person, or starting pricing. Add deposits and travel fees only where appropriate." },
      { title: "Publish clear policies", body: "Explain cancellation, rescheduling, overtime, location, and customer requirements." },
    ],
  },
  {
    slug: "order-and-track",
    title: "Order and track your food",
    summary: "How customers choose a trusted Prepper, confirm fulfillment, communicate, and leave a verified review.",
    audience: "Customers",
    minutes: 4,
    steps: [
      { title: "Choose the right offering", body: "Compare meals, plans, Prepper profiles, ingredients, allergens, ratings, and fulfillment windows." },
      { title: "Review the total", body: "Confirm quantity, fees, tip, address or pickup details, and scheduled time before payment." },
      { title: "Track the order", body: "Follow confirmation, preparation, ready, delivery, and completion updates in Orders." },
      { title: "Resolve issues in the app", body: "Use order chat and support so there is a clear record for both customer and Prepper." },
      { title: "Review after completion", body: "Verified reviews become available only after a completed transaction." },
    ],
  },
  {
    slug: "safety-and-standards",
    title: "Safety and community standards",
    summary: "The practical rules that protect customers, Preppas, kitchens, payments, and community trust.",
    audience: "Everyone",
    minutes: 6,
    steps: [
      { title: "Be accurate", body: "Descriptions, photos, availability, ingredients, service terms, and pricing must match reality." },
      { title: "Keep payments in Preppa", body: "Do not request off-platform payment, banking information, passwords, or verification codes." },
      { title: "Respect allergy information", body: "Clearly disclose known allergens and limitations. Never make medical guarantees." },
      { title: "Use respectful communication", body: "Harassment, discriminatory conduct, threats, spam, and manipulation are not permitted." },
      { title: "Report problems", body: "Use in-app reporting so safety and support teams can preserve evidence and respond appropriately." },
    ],
  },
];

export const guideBySlug = Object.fromEntries(guides.map((guide) => [guide.slug, guide]));
