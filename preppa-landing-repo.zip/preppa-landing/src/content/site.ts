export const siteConfig = {
  name: "preppa",
  description: "Meals, meal plans, and local food services from trusted Preppas near you.",
  siteUrl: process.env.NEXT_PUBLIC_SITE_URL ?? "https://preppa.live",
  appUrl: process.env.NEXT_PUBLIC_APP_URL ?? "https://app.preppa.live",
  tiktok: process.env.NEXT_PUBLIC_TIKTOK_URL ?? "https://www.tiktok.com/@preppa.live",
  instagram: process.env.NEXT_PUBLIC_INSTAGRAM_URL ?? "https://www.instagram.com/preppa.live",
};

export const servicePillars = [
  {
    title: "Meals made for real life",
    body: "Order a one-time meal, a family bundle, or a limited Meal Drop from a local kitchen.",
    tag: "Order",
  },
  {
    title: "Weekly meal plans",
    body: "Build a routine around recurring meals, dietary preferences, pickup, or scheduled delivery.",
    tag: "Subscribe",
  },
  {
    title: "Food services & experiences",
    body: "Book cooking classes, private dining, catering, or a Prepper who cooks in your home.",
    tag: "Book",
  },
  {
    title: "Custom requests & quotes",
    body: "Post what you need, compare qualified Prepper quotes, then confirm securely in Preppa.",
    tag: "Request",
  },
];

export const cuisineLoop = [
  "Nigerian", "Jamaican", "Halal", "Plant-Based", "High Protein", "Ethiopian", "Caribbean", "Keto", "Thai", "Mexican", "Family Meals", "Meal Prep"
];
