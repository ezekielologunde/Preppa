import type { MetadataRoute } from "next";
import { guides } from "@/content/learn";
import { legalPages } from "@/content/legal";
import { siteConfig } from "@/content/site";
export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  return [
    { url: siteConfig.siteUrl, lastModified: now, changeFrequency: "weekly", priority: 1 },
    { url: `${siteConfig.siteUrl}/learn`, lastModified: now, changeFrequency: "monthly", priority: .8 },
    { url: `${siteConfig.siteUrl}/legal`, lastModified: now, changeFrequency: "monthly", priority: .7 },
    ...guides.map(({ slug }) => ({ url: `${siteConfig.siteUrl}/learn/${slug}`, lastModified: now, changeFrequency: "monthly" as const, priority: .65 })),
    ...legalPages.map(({ slug }) => ({ url: `${siteConfig.siteUrl}/legal/${slug}`, lastModified: now, changeFrequency: "monthly" as const, priority: .55 })),
  ];
}
