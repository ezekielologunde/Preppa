import Link from "next/link";
import { ArrowRight, BookOpen, Clock3 } from "lucide-react";
import { MotionReveal } from "@/components/motion-reveal";
import { guides } from "@/content/learn";

export const metadata = { title: "Learning Center", description: "Learn how to order, sell, create plans, set up payouts, and use Preppa safely." };

export default function LearnPage() {
  return <main className="container-shell py-20">
    <MotionReveal><p className="eyebrow text-[var(--orange-deep)]">Preppa Learning Center</p><h1 className="section-title mt-5 max-w-5xl">Everything important, explained before it becomes a support ticket.</h1><p className="body-large mt-6 max-w-3xl text-black/55">Short, public guides for customers and approved Preppas. Each guide connects the product flow, platform rules, and practical next step.</p></MotionReveal>
    <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
      {guides.map((guide, index) => <MotionReveal delay={index * .04} key={guide.slug}><Link href={`/learn/${guide.slug}`} className="card-flat group flex min-h-72 flex-col p-7 transition hover:-translate-y-1 hover:bg-white"><div className="flex items-center justify-between"><span className="rounded-full bg-[var(--peach)] px-3 py-1 text-xs font-black">{guide.audience}</span><BookOpen size={20} /></div><h2 className="mt-10 text-3xl font-black tracking-[-.045em]">{guide.title}</h2><p className="mt-4 flex-1 leading-7 text-black/55">{guide.summary}</p><div className="mt-7 flex items-center justify-between text-sm font-bold"><span className="flex items-center gap-2 text-black/45"><Clock3 size={16} /> {guide.minutes} min</span><ArrowRight className="transition group-hover:translate-x-1" /></div></Link></MotionReveal>)}
    </div>
  </main>;
}
