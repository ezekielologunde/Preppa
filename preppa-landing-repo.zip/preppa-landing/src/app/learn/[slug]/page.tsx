import Link from "next/link";
import { ArrowLeft, CircleAlert, Clock3 } from "lucide-react";
import { notFound } from "next/navigation";
import { guideBySlug, guides } from "@/content/learn";

export function generateStaticParams() { return guides.map(({ slug }) => ({ slug })); }

export default async function GuidePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const guide = guideBySlug[slug];
  if (!guide) notFound();
  return <main className="container-shell py-16">
    <Link className="inline-flex items-center gap-2 font-bold text-black/55 hover:text-black" href="/learn"><ArrowLeft size={18} /> Learning Center</Link>
    <div className="mt-10 grid gap-12 lg:grid-cols-[.7fr_1.3fr]">
      <aside><span className="rounded-full bg-[var(--peach)] px-3 py-1 text-xs font-black">{guide.audience}</span><h1 className="section-title mt-6">{guide.title}</h1><p className="body-large mt-6 text-black/55">{guide.summary}</p><p className="mt-6 flex items-center gap-2 text-sm font-bold text-black/45"><Clock3 size={17} /> About {guide.minutes} minutes</p></aside>
      <article className="card p-6 md:p-9">
        <ol className="grid gap-4">{guide.steps.map((step, index) => <li key={step.title} className="grid gap-4 rounded-[1.6rem] border border-black/10 bg-white/65 p-6 md:grid-cols-[3.2rem_1fr]"><span className="grid size-11 place-items-center rounded-full bg-[var(--orange)] font-black text-white">{index + 1}</span><div><h2 className="text-2xl font-black tracking-[-.03em]">{step.title}</h2><p className="mt-3 leading-7 text-black/55">{step.body}</p></div></li>)}</ol>
        {guide.note && <div className="mt-6 flex gap-3 rounded-2xl bg-amber-100 p-5 text-amber-950"><CircleAlert className="mt-1 shrink-0" size={20} /><p className="leading-7">{guide.note}</p></div>}
      </article>
    </div>
  </main>;
}
