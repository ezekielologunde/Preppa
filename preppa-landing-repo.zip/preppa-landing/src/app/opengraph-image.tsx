import { ImageResponse } from "next/og";
export const alt = "Preppa — real food from real local Preppas";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";
export default function Image() {
  return new ImageResponse(<div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: 72, color: "#17130f", background: "linear-gradient(135deg,#fffaf2 0%,#ffd8c8 55%,#d9ff5c 100%)", fontFamily: "Arial" }}><div style={{ display: "flex", alignItems: "center", gap: 16, fontSize: 42, fontWeight: 900 }}><div style={{ display: "flex", width: 62, height: 62, borderRadius: 999, alignItems: "center", justifyContent: "center", background: "#ff5a24", color: "white" }}>p</div>preppa</div><div style={{ display: "flex", flexDirection: "column", fontSize: 94, fontWeight: 900, lineHeight: .9, letterSpacing: -6 }}><span>Real food.</span><span>Real local.</span><span>Real Preppas.</span></div><div style={{ fontSize: 28 }}>Meals, meal plans, and local food services near you.</div></div>, size);
}
