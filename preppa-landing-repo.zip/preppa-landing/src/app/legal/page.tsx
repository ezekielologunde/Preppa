import Link from "next/link";
import { ArrowRight, Scale } from "lucide-react";
import { legalPages } from "@/content/legal";

export const metadata = { title: "Legal & Safety Center" };
export default function LegalPage() {
  return <main className="container-shell py-20"><p className="eyebrow text-[var(--orange-deep)]">Legal & Safety Center</p><h1 className="section-title mt-5 max-w-5xl">Clear rules before legal copy becomes decorative wallpaper.</h1><p className="body-large mt-6 max-w-3xl text-black/55">These pages organize launch requirements and public-facing policy concepts. Draft legal frameworks must still be reviewed by qualified counsel.</p><div className="mt-14 grid gap-5 md:grid-cols-2">{legalPages.map((page) => <Link className="card-flat group p-7 transition hover:-translate-y-1 hover:bg-white" key={page.slug} href={`/legal/${page.slug}`}><Scale /><h2 className="mt-10 text-3xl font-black tracking-[-.04em]">{page.title}</h2><p className="mt-4 leading-7 text-black/55">{page.summary}</p><ArrowRight className="mt-7 transition group-hover:translate-x-1" /></Link>)}</div></main>;
}
