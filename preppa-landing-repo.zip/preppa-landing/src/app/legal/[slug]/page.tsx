import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { notFound } from "next/navigation";
import { legalBySlug, legalPages } from "@/content/legal";

export function generateStaticParams() { return legalPages.map(({ slug }) => ({ slug })); }

export default async function LegalDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const page = legalBySlug[slug];
  if (!page) notFound();
  return <main className="container-shell py-16"><Link className="inline-flex items-center gap-2 font-bold text-black/55 hover:text-black" href="/legal"><ArrowLeft size={18} /> Legal & Safety Center</Link><article className="prose-preppa mx-auto mt-10 max-w-4xl rounded-[2.5rem] border border-black/10 bg-white/70 p-7 shadow-[var(--shadow)] md:p-12"><p className="eyebrow text-[var(--orange-deep)]">Preppa public policy framework</p><h1 className="section-title mt-5">{page.title}</h1><p className="body-large mt-6">{page.summary}</p>{page.sections.map((section) => <section key={section.heading}><h2>{section.heading}</h2>{section.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}{section.bullets && <ul>{section.bullets.map((bullet) => <li key={bullet}>{bullet}</li>)}</ul>}</section>)}</article></main>;
}
