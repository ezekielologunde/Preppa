import type { Metadata } from "next";
import { Analytics } from "@vercel/analytics/next";
import { SpeedInsights } from "@vercel/speed-insights/next";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { siteConfig } from "@/content/site";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.siteUrl),
  title: { default: "Preppa | Real food from real local Preppas", template: "%s | Preppa" },
  description: siteConfig.description,
  applicationName: "Preppa",
  alternates: { canonical: "/" },
  openGraph: { title: "Preppa", description: siteConfig.description, url: siteConfig.siteUrl, siteName: "Preppa", type: "website" },
  twitter: { card: "summary_large_image", title: "Preppa", description: siteConfig.description },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><SiteHeader />{children}<SiteFooter /><Analytics /><SpeedInsights /></body></html>;
}
