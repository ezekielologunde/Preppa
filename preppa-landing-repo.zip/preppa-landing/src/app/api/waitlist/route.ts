import { NextResponse } from "next/server";

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const zipPattern = /^\d{5}(?:-\d{4})?$/;
const roles = new Set(["customer", "prepper", "both"]);

export async function POST(request: Request) {
  const body = await request.json().catch(() => null) as null | Record<string, unknown>;
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  const zip = typeof body?.zip === "string" ? body.zip.trim() : "";
  const role = typeof body?.role === "string" ? body.role : "customer";
  if (!emailPattern.test(email) || !zipPattern.test(zip) || !roles.has(role)) return NextResponse.json({ error: "Enter a valid email, ZIP code, and role." }, { status: 400 });

  const webhook = process.env.WAITLIST_WEBHOOK_URL;
  if (!webhook) return NextResponse.json({ error: "Waitlist collection is not configured yet. Add WAITLIST_WEBHOOK_URL in Vercel." }, { status: 503 });

  const response = await fetch(webhook, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email, zip, role, source: "preppa.live", submittedAt: new Date().toISOString() }), signal: AbortSignal.timeout(8000) });
  if (!response.ok) return NextResponse.json({ error: "The waitlist service is temporarily unavailable." }, { status: 502 });
  return NextResponse.json({ ok: true });
}
