"use client";

import Link from "next/link";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { BrandMark } from "@/components/brand-mark";
import { siteConfig } from "@/content/site";

const links = [
  ["Discover", "/#discover"],
  ["For Preppas", "/#preppas"],
  ["Learn", "/learn"],
  ["Safety", "/legal/community-guidelines"],
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-black/10 bg-[rgba(255,250,242,.84)] backdrop-blur-xl">
      <div className="container-shell flex min-h-18 items-center justify-between gap-4">
        <Link href="/" aria-label="Preppa home"><BrandMark /></Link>
        <nav className="hidden items-center gap-7 md:flex" aria-label="Primary navigation">
          {links.map(([label, href]) => <Link className="text-sm font-bold text-black/70 transition hover:text-black" key={href} href={href}>{label}</Link>)}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          <Link className="btn-secondary" href="#waitlist">Join waitlist</Link>
          <a className="btn-dark" href={siteConfig.appUrl}>Open app</a>
        </div>
        <button className="grid size-11 place-items-center rounded-full border border-black/10 bg-white md:hidden" onClick={() => setOpen((v) => !v)} aria-expanded={open} aria-label="Toggle navigation">
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>
      {open && (
        <div className="container-shell grid gap-2 pb-5 md:hidden">
          {links.map(([label, href]) => <Link className="rounded-2xl px-4 py-3 font-bold hover:bg-white" key={href} href={href} onClick={() => setOpen(false)}>{label}</Link>)}
          <Link className="btn-primary mt-2" href="#waitlist" onClick={() => setOpen(false)}>Join waitlist</Link>
        </div>
      )}
    </header>
  );
}
