export function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2 font-black tracking-[-0.06em]" aria-label="Preppa">
      <span className="grid size-9 place-items-center rounded-full bg-[var(--orange)] text-white shadow-[0_8px_22px_rgba(255,90,36,.3)]">p</span>
      {!compact && <span className="text-2xl">preppa</span>}
    </span>
  );
}
