"use client";

import { ArrowRight, CheckCircle2 } from "lucide-react";
import { FormEvent, useState } from "react";

export function WaitlistForm() {
  const [state, setState] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState("loading");
    setMessage("");
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries());
    try {
      const response = await fetch("/api/waitlist", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Unable to join right now.");
      setState("success");
      setMessage("You’re on the list. We’ll let you know when Preppa reaches your area.");
      event.currentTarget.reset();
    } catch (error) {
      setState("error");
      setMessage(error instanceof Error ? error.message : "Unable to join right now.");
    }
  }

  return (
    <form onSubmit={submit} className="grid gap-3" aria-describedby="waitlist-message">
      <div className="grid gap-3 md:grid-cols-[1fr_.55fr_.55fr_auto]">
        <label className="sr-only" htmlFor="email">Email</label>
        <input required id="email" name="email" type="email" autoComplete="email" placeholder="you@example.com" className="min-h-13 rounded-full border border-black/10 bg-white px-5 outline-none" />
        <label className="sr-only" htmlFor="zip">ZIP code</label>
        <input required id="zip" name="zip" inputMode="numeric" pattern="[0-9]{5}(-[0-9]{4})?" placeholder="ZIP code" className="min-h-13 rounded-full border border-black/10 bg-white px-5 outline-none" />
        <label className="sr-only" htmlFor="role">I am joining as</label>
        <select id="role" name="role" className="min-h-13 rounded-full border border-black/10 bg-white px-5 outline-none">
          <option value="customer">Customer</option>
          <option value="prepper">Future Prepper</option>
          <option value="both">Both</option>
        </select>
        <button className="btn-dark" disabled={state === "loading"} type="submit">
          {state === "loading" ? "Joining…" : "Join"} <ArrowRight size={18} />
        </button>
      </div>
      <p id="waitlist-message" className={`min-h-6 text-sm ${state === "error" ? "text-red-700" : "text-black/60"}`} role="status">
        {state === "success" && <CheckCircle2 className="mr-2 inline" size={16} />}{message || "No spam. Just launch news, local availability, and useful Preppa updates."}
      </p>
    </form>
  );
}
