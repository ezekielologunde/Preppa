import Link from "next/link";
import { Camera, Music2 } from "lucide-react";
import { BrandMark } from "@/components/brand-mark";
import { siteConfig } from "@/content/site";

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-white/10 bg-[var(--ink)] text-white">
      <div className="container-shell grid gap-12 py-16 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <BrandMark />
          <p className="mt-5 max-w-md text-lg leading-8 text-white/65">Meals, meal plans, and local food services from trusted Preppas near you.</p>
          <div className="mt-6 flex gap-3">
            <a className="grid size-11 place-items-center rounded-full border border-white/15 hover:bg-white/10" href={siteConfig.instagram} aria-label="Preppa on Instagram"><Camera size={19} /></a>
            <a className="grid size-11 place-items-center rounded-full border border-white/15 hover:bg-white/10" href={siteConfig.tiktok} aria-label="Preppa on TikTok"><Music2 size={19} /></a>
          </div>
        </div>
        <div>
          <p className="eyebrow text-white/45">Learn</p>
          <div className="mt-4 grid gap-3 text-white/75">
            <Link href="/learn/create-a-meal-plan">Create a meal plan</Link>
            <Link href="/learn/post-your-first-meal">Post your first meal</Link>
            <Link href="/learn/set-up-payouts">Set up payouts</Link>
            <Link href="/learn/offer-an-experience">Offer an experience</Link>
          </div>
        </div>
        <div>
          <p className="eyebrow text-white/45">Legal & safety</p>
          <div className="mt-4 grid gap-3 text-white/75">
            <Link href="/legal/privacy">Privacy</Link>
            <Link href="/legal/terms">Terms framework</Link>
            <Link href="/legal/community-guidelines">Community guidelines</Link>
            <Link href="/legal/preppa-standards">Prepper standards</Link>
          </div>
        </div>
      </div>
      <div className="container-shell flex flex-col gap-3 border-t border-white/10 py-6 text-sm text-white/45 md:flex-row md:items-center md:justify-between">
        <p>© {new Date().getFullYear()} Preppa. Real food. Real local.</p>
        <p>Launch content is subject to operational and legal review.</p>
      </div>
    </footer>
  );
}
