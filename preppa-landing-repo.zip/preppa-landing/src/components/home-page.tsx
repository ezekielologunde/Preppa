"use client";

import Link from "next/link";
import { ArrowRight, BadgeCheck, CalendarDays, ChefHat, CircleDollarSign, Clock3, Flame, Play, ShieldCheck, Sparkles, Users } from "lucide-react";
import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import { MotionReveal } from "@/components/motion-reveal";
import { WaitlistForm } from "@/components/waitlist-form";
import { cuisineLoop, servicePillars } from "@/content/site";

export function HomePage() {
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : -100]);
  const loop = [...cuisineLoop, ...cuisineLoop];

  return (
    <main className="grain overflow-hidden">
      <section className="container-shell relative grid min-h-[820px] items-center gap-12 py-20 lg:grid-cols-[1.06fr_.94fr]">
        <div className="relative z-10">
          <MotionReveal><p className="eyebrow text-[var(--orange-deep)]">A local meal-prep and food-services marketplace</p></MotionReveal>
          <MotionReveal delay={.06}><h1 className="display mt-6">Real food.<br />Real local.<br /><span className="text-[var(--orange)]">Real Preppas.</span></h1></MotionReveal>
          <MotionReveal delay={.12}><p className="body-large mt-7 max-w-2xl text-black/65">Order a fresh meal, subscribe to a weekly plan, or book a trusted local food service. Skip the chains and build a food routine around real people near you.</p></MotionReveal>
          <MotionReveal delay={.18} className="mt-8 flex flex-wrap gap-3">
            <Link className="btn-primary" href="#waitlist">Join your neighborhood <ArrowRight size={18} /></Link>
            <Link className="btn-secondary" href="/learn">See how Preppa works</Link>
          </MotionReveal>
          <MotionReveal delay={.22} className="mt-7 flex flex-wrap gap-x-6 gap-y-3 text-sm font-bold text-black/55">
            <span className="flex items-center gap-2"><BadgeCheck size={18} className="text-[var(--orange)]" /> Approved local Preppas</span>
            <span className="flex items-center gap-2"><ShieldCheck size={18} className="text-[var(--orange)]" /> Secure payments & payouts</span>
            <span className="flex items-center gap-2"><CalendarDays size={18} className="text-[var(--orange)]" /> Meals, plans & experiences</span>
          </MotionReveal>
        </div>

        <motion.div style={{ y }} className="relative min-h-[600px]">
          <div className="mesh absolute inset-x-8 top-16 h-[470px] -rotate-3 rounded-[3rem] shadow-[0_35px_100px_rgba(130,52,10,.25)]" />
          <motion.div animate={reduce ? undefined : { y: [0, -14, 0], rotate: [-1, 1, -1] }} transition={{ repeat: Infinity, duration: 7, ease: "easeInOut" }} className="card absolute left-0 top-0 w-[78%] p-5">
            <div className="flex items-center justify-between"><span className="eyebrow text-black/45">This week near you</span><Flame className="text-[var(--orange)]" /></div>
            <div className="mt-4 rounded-[1.6rem] bg-[var(--ink)] p-6 text-white">
              <p className="text-sm text-white/55">Meal plan</p><h2 className="mt-2 text-3xl font-black tracking-[-.04em]">High-Protein Workweek</h2>
              <div className="mt-7 flex items-end justify-between"><p className="text-white/65">10 meals · Sunday delivery</p><p className="text-2xl font-black">$118<span className="text-sm text-white/45">/wk</span></p></div>
            </div>
          </motion.div>
          <motion.div animate={reduce ? undefined : { y: [0, 18, 0] }} transition={{ repeat: Infinity, duration: 8.5, ease: "easeInOut" }} className="card absolute bottom-8 right-0 w-[74%] p-5">
            <div className="flex gap-4"><div className="grid size-14 shrink-0 place-items-center rounded-2xl bg-[var(--orange)] text-white"><ChefHat /></div><div><p className="font-black">Chef Amara’s kitchen</p><p className="mt-1 text-sm text-black/50">West African · Family meals</p></div></div>
            <div className="mt-5 grid grid-cols-3 gap-2 text-center text-sm font-bold"><div className="rounded-xl bg-black/5 p-3">4.9 ★</div><div className="rounded-xl bg-black/5 p-3">2.4 mi</div><div className="rounded-xl bg-black/5 p-3">Verified</div></div>
          </motion.div>
          <motion.div animate={reduce ? undefined : { rotate: [0, 8, 0], scale: [1, 1.04, 1] }} transition={{ repeat: Infinity, duration: 6 }} className="absolute right-6 top-5 grid size-24 place-items-center rounded-full bg-[var(--lime)] text-center text-sm font-black shadow-xl">MEAL<br />DROP<br />LIVE</motion.div>
          <motion.div animate={reduce ? undefined : { x: [0, 10, 0] }} transition={{ repeat: Infinity, duration: 5 }} className="absolute bottom-14 left-0 flex items-center gap-3 rounded-full bg-white px-5 py-3 font-black shadow-xl"><Play size={18} fill="currentColor" /> Watch local kitchens</motion.div>
        </motion.div>
      </section>

      <div className="marquee" aria-label="Cuisines and meal categories">
        <div className="marquee-track">{loop.map((item, index) => <span className="marquee-item" key={`${item}-${index}`}>{item} <span className="ml-5 text-[var(--orange)]">●</span></span>)}</div>
      </div>

      <section id="discover" className="container-shell py-28">
        <MotionReveal><p className="eyebrow text-[var(--orange-deep)]">More than delivery</p><h2 className="section-title mt-5 max-w-4xl">One place for the way you actually need food.</h2></MotionReveal>
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {servicePillars.map((pillar, index) => (
            <MotionReveal delay={index * .06} key={pillar.title}>
              <article className="card-flat group min-h-72 overflow-hidden p-8 transition hover:-translate-y-1 hover:bg-white">
                <div className="flex items-center justify-between"><span className="eyebrow text-[var(--orange-deep)]">{pillar.tag}</span><ArrowRight className="transition group-hover:translate-x-1" /></div>
                <h3 className="mt-14 text-4xl font-black tracking-[-.05em]">{pillar.title}</h3><p className="mt-4 max-w-lg text-lg leading-8 text-black/55">{pillar.body}</p>
              </article>
            </MotionReveal>
          ))}
        </div>
      </section>

      <section className="bg-[var(--ink)] py-28 text-white">
        <div className="container-shell grid gap-14 lg:grid-cols-[.85fr_1.15fr]">
          <MotionReveal><p className="eyebrow text-[var(--orange)]">How it works</p><h2 className="section-title mt-5">Your food routine, without restaurant roulette.</h2><p className="body-large mt-6 text-white/55">Find the right local person, not just the nearest menu item.</p></MotionReveal>
          <div className="grid gap-4">
            {[
              ["01", "Find your Preppa", "Browse trusted local kitchens by cuisine, dietary fit, meal plans, services, ratings, and availability."],
              ["02", "Choose your rhythm", "Order once, subscribe weekly, claim a Drop, book an experience, or request a custom quote."],
              ["03", "Track it clearly", "Keep payment, messages, status updates, reviews, and support connected to the same transaction."],
            ].map(([num, title, body], index) => (
              <MotionReveal delay={index * .08} key={num}>
                <article className="grid gap-4 rounded-[2rem] border border-white/10 bg-white/[.055] p-7 md:grid-cols-[5rem_1fr]">
                  <span className="text-4xl font-black text-[var(--orange)]">{num}</span><div><h3 className="text-2xl font-black">{title}</h3><p className="mt-3 text-lg leading-8 text-white/55">{body}</p></div>
                </article>
              </MotionReveal>
            ))}
          </div>
        </div>
      </section>

      <section id="preppas" className="container-shell py-28">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <MotionReveal className="card mesh min-h-[580px] overflow-hidden p-7">
            <div className="rounded-[2rem] bg-[var(--ink)] p-6 text-white shadow-2xl">
              <div className="flex items-center justify-between"><div><p className="eyebrow text-white/45">My Hub</p><p className="mt-2 text-3xl font-black">Good morning, Amara</p></div><div className="grid size-12 place-items-center rounded-2xl bg-[var(--orange)]"><ChefHat /></div></div>
              <div className="mt-7 grid grid-cols-2 gap-3"><div className="rounded-2xl bg-white/8 p-5"><p className="text-white/45">This week</p><p className="mt-2 text-3xl font-black">42 meals</p></div><div className="rounded-2xl bg-white/8 p-5"><p className="text-white/45">Pending payout</p><p className="mt-2 text-3xl font-black">$684</p></div></div>
              <div className="mt-4 rounded-2xl bg-white p-5 text-[var(--ink)]"><p className="font-black">Next prep list</p><div className="mt-4 grid gap-3 text-sm"><span className="flex justify-between"><b>Jollof + chicken</b><span>16 portions</span></span><span className="flex justify-between"><b>Protein bowls</b><span>12 portions</span></span><span className="flex justify-between"><b>Egusi + pounded yam</b><span>8 portions</span></span></div></div>
            </div>
          </MotionReveal>
          <MotionReveal>
            <p className="eyebrow text-[var(--orange-deep)]">Built for Preppas</p><h2 className="section-title mt-5">Turn your kitchen skill into a real local business.</h2><p className="body-large mt-6 text-black/60">Create meals, weekly plans, services, videos, and experiences. Manage capacity, orders, subscribers, quotes, reviews, earnings, and secure payouts from one My Hub.</p>
            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              {[[CircleDollarSign, "Secure payouts"], [Users, "Subscribers & bookings"], [Clock3, "Capacity & availability"], [Sparkles, "Creator feed & Drops"]].map(([Icon, label]) => { const I = Icon as typeof CircleDollarSign; return <div className="card-flat flex items-center gap-3 p-4 font-black" key={label as string}><span className="grid size-10 place-items-center rounded-xl bg-[var(--peach)]"><I size={20} /></span>{label as string}</div>; })}
            </div>
            <Link className="btn-primary mt-8" href="/learn/become-a-preppa">Learn how approval works <ArrowRight size={18} /></Link>
          </MotionReveal>
        </div>
      </section>

      <section className="container-shell pb-28">
        <div className="rounded-[3rem] bg-[var(--cream)] p-7 md:p-12">
          <MotionReveal><p className="eyebrow text-[var(--orange-deep)]">Learn Preppa</p><h2 className="section-title mt-5 max-w-4xl">Practical guidance, not mystery buttons.</h2><p className="body-large mt-5 max-w-3xl text-black/55">The landing site doubles as the public training center for customers and Preppas.</p></MotionReveal>
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {[
              ["Post your first meal", "From draft to safe, clear, purchasable listing.", "/learn/post-your-first-meal"],
              ["Create a meal plan", "Build the menu, cadence, capacity, price, and policies.", "/learn/create-a-meal-plan"],
              ["Set up payouts", "Understand approval, secure onboarding, and payout readiness.", "/learn/set-up-payouts"],
            ].map(([title, body, href], index) => <MotionReveal delay={index * .06} key={href}><Link href={href} className="group block h-full rounded-[1.7rem] bg-white p-6 shadow-sm transition hover:-translate-y-1"><h3 className="text-2xl font-black tracking-[-.035em]">{title}</h3><p className="mt-3 leading-7 text-black/55">{body}</p><ArrowRight className="mt-8 transition group-hover:translate-x-1" /></Link></MotionReveal>)}
          </div>
          <Link className="btn-dark mt-8" href="/learn">Explore the training center</Link>
        </div>
      </section>

      <section id="waitlist" className="container-shell pb-24">
        <MotionReveal className="mesh rounded-[3rem] p-7 shadow-[0_35px_100px_rgba(130,52,10,.2)] md:p-12">
          <p className="eyebrow">Launching neighborhood by neighborhood</p><h2 className="section-title mt-5 max-w-4xl">Bring real local food to your block.</h2><p className="body-large mt-5 max-w-3xl text-black/65">Drop your ZIP, tell us whether you want to order or cook, and we’ll prioritize the areas with the strongest local demand.</p><div className="mt-8"><WaitlistForm /></div>
        </MotionReveal>
      </section>
    </main>
  );
}
