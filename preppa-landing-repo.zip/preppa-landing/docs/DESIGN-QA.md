# Design QA

## Direction

The site should feel like a vivid neighborhood food culture brand, not a generic SaaS landing page or restaurant-delivery clone.

## Non-negotiables

- Strong editorial typography
- Warm food-derived palette
- Real hierarchy, not card overload
- Motion with purpose
- Reduced-motion support
- No fake controls
- No dead CTAs
- Every training and policy card opens a valid route
- Mobile-first navigation
- Contrast and 44px targets

## Agent tools

Use Impeccable or UI/UX Pro Max to critique hierarchy, spacing, typography, motion, and responsiveness. Run one design vocabulary at a time, compare against these non-negotiables, and reject changes that introduce generic gradients, excessive glass cards, unreadable low contrast, or decorative interactions without function.
