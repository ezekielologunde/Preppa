# Content Map

## Homepage

- Brand promise
- Waitlist and neighborhood expansion
- Meals, meal plans, services, experiences, and requests
- Customer flow
- Prepper business value
- Training hub entry points
- Social profiles

## Learning Center

- Apply to become a Prepper
- Post first meal
- Create meal plan
- Set up payouts
- Offer experience
- Customer ordering and tracking
- Safety and standards

## Legal and Safety Center

- Privacy framework
- Terms framework
- Community guidelines
- Prepper standards
- Refund and cancellation framework

All legal framework pages require counsel review before being treated as binding documents.
