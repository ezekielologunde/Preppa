# Deployment and Existing Vercel Project Handoff

## Existing project reference

- Vercel project ID: `prj_gPthFPn7fctBvhLofNfxrRUzwKeX`
- Production domain: `preppa.live`

A project ID is not an authentication credential, but do not treat it as sufficient authorization. Linking or changing Git requires access to the owning Vercel team.

## Safe migration order

1. Create the GitHub repository from this package.
2. Run `npm run check` from a clean clone.
3. Create a Vercel preview deployment first.
4. Verify every route, form state, social link, metadata image, sitemap, and mobile breakpoint.
5. In the existing Vercel project, open Settings → Git.
6. Connect the new GitHub repository or disconnect the old one only after the preview passes.
7. Confirm the Production Branch is `main`.
8. Add environment variables from `.env.example`.
9. Confirm `preppa.live` and `www.preppa.live` domain assignments.
10. Deploy production.
11. Smoke-test the production domain.
12. Preserve the previous deployment for immediate rollback.

## Required environment variables

- `NEXT_PUBLIC_SITE_URL`
- `NEXT_PUBLIC_APP_URL`
- `NEXT_PUBLIC_TIKTOK_URL`
- `NEXT_PUBLIC_INSTAGRAM_URL`
- `WAITLIST_WEBHOOK_URL`

## Rollback

Use Vercel’s deployment list to promote the last known-good deployment. Do not change DNS during a normal application rollback.
