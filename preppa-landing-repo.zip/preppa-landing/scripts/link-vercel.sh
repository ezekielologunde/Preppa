#!/usr/bin/env bash
set -euo pipefail
command -v vercel >/dev/null || { echo "Vercel CLI is required: npm i -g vercel" >&2; exit 1; }
vercel link
vercel env pull .env.local
printf '\nLinked. Run `npm run check`, then `vercel` for preview and `vercel --prod` only after approval.\n'
