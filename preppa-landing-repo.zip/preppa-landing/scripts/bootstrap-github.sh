#!/usr/bin/env bash
set -euo pipefail
REPO_NAME="${1:-preppa-landing}"
VISIBILITY="${2:---private}"
command -v gh >/dev/null || { echo "GitHub CLI (gh) is required." >&2; exit 1; }
gh auth status >/dev/null
git init
git add .
git commit -m "feat: launch Preppa marketing and learning hub"
gh repo create "$REPO_NAME" "$VISIBILITY" --source=. --remote=origin --push
